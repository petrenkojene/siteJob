function click(){
  window.location.assign("https://www.w3schools.com");
}
